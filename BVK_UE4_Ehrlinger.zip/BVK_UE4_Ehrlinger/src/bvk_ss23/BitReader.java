package bvk_ss23;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class BitReader {
    private DataInputStream in;
    private ArrayList<Integer> buffer;
    public BitReader(DataInputStream in) {
        super();
        this.in = in;
        buffer = new ArrayList<Integer>();
    }
    int[] read(int readNumber) throws IOException {
        if(readNumber <=0) {
            int[] reti = {0};
            return reti;
        }
        int remainingBits = readNumber;
        int[] reti = new int[readNumber];
        for (int i = 0;  buffer.size() > 0; i++) {
            reti[i] = buffer.remove(0);
            remainingBits--;
            if(remainingBits == 0) return reti;
        }

        if(readNumber > buffer.size());
        int offset = readNumber - remainingBits;
        for(int i = 0; i < Math.ceil((double) remainingBits / 8); i++) {

            byte readByte = in.readByte();
            for(int f = 0; f < 8; f++) {
                if(remainingBits > 0) {
                    reti[f + offset + 8 * i] = readByte >> ((8 - f) - 1)  & 1;
                    remainingBits--;
                }else{
                    buffer.add(readByte >> ((8 - f) - 1) & 1);
                }
            }
        }
        if(remainingBits == 0)return reti;

        return reti;
    }

    public void close() {
        try {
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
