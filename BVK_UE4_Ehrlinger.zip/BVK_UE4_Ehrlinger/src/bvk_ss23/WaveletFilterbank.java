package bvk_ss23;

import java.io.IOException;
import java.util.Arrays;

public class WaveletFilterbank {

    public static RasterImage transformation(RasterImage image) throws IOException {
        Object[] horizontal = LiftingAnalyse(image.argb, 1, image);
        return synthese(horizontal, image);
    }

    public static RasterImage show(RasterImage image) throws IOException {

        Object[] horizontal = LiftingAnalyse(image.argb, 1, image);
        /*Object[] vertical = LiftingAnalyse((int[]) horizontal[0], 0, image);
        Object[] vertical2 = LiftingAnalyse((int[]) horizontal[1], 0, image);

        int[]c1 = (int[])vertical[0];
        int[]c2 = (int[])vertical[1];
        int[]c3 = (int[])vertical2[0];
        int[]c4 = (int[])vertical2[1];*/

        int[]c1 = (int[])horizontal[0];
        int[]c2 = (int[])horizontal[1];

        RasterImage show = new RasterImage(image.width, image.height);

        int count1 = 0;
        int count2 = 0;
        //int count3 = 0;
        //int count4 = 0;

        for(int y = 0; y<show.height; y++ ){
            for (int x = 0; x < show.width; x++) {
                int pos = y * show.width + x;
                if(x<show.width/2){
                   show.argb[pos] = c1[count1];
                   count1++;
                }
                else{
                    show.argb[pos] = c2[count2];
                    count2++;
                }
               /* if (x < show.width/2 && y < show.height/2) {
                    show.argb[pos] = c1[count1];
                    count1++;
                } else if (x >= show.width/2 && y < show.height/2) {
                    show.argb[pos] = c2[count2];
                    count2++;
                } else if (x < show.width/2 && y >= show.height/2) {
                    show.argb[pos] = c3[count3];
                    count3++;
                } else{
                    show.argb[pos] = c4[count4];
                    count4++;
                }*/
            }
        }

        for(int i = 0; i<show.argb.length; i++){
            show.argb[i] = (0xFF<<24) | (show.argb[i]<<16) | (show.argb[i] << 8) | show.argb[i];
        }
        return show;
    }

    public static RasterImage synthese(Object[] arrays, RasterImage image) throws IOException {
        int[]c0 = (int[]) arrays[0];
        int[]c1 = (int[]) arrays[1];
        /*int[]c2 = (int[]) arrays[2];
        int[]c3 = (int[]) arrays[3];*/

        /*int[] argbHorizontal = LiftingSynthese(c0, c1);
        int[] argbVertical = LiftingSynthese(c2, c3);*/

        /*image.argb = LiftingSynthese(argbHorizontal, argbVertical);*/

        image.argb = LiftingSynthese(c0, c1);

        return image;
    }

    public static Object[] LiftingAnalyse(int[] argb, int mode, RasterImage image){

        int [] even = new int[argb.length];
        int [] odd = new int[argb.length];

        int[] c1 = new int[argb.length/2];
        int[] c2 = new int[argb.length/2];

        if(mode == 1){
            for(int i = 0; i < argb.length; i++){
                if(i % 2 == 0) even[i] = image.getlum(i);
                else odd[i] = image.getlum(i);
            }
            calc(even, odd, c1, c2);
        }

        else{
            int eveni = 0;
            int oddi = 0;
            int count = 0;

            for(int x = 0; x < image.width; x++){
                for(int y = 0; y < image.height; y++){
                    int pos = y * image.width + x;
                    if(count % 2 == 0){
                        even[eveni] = image.getlum(pos);
                        eveni++;
                        count++;
                    }
                    else{
                        odd[oddi] = image.getlum(pos);
                        oddi++;
                        count++;
                    }
                }
            }
            int[] c1help = new int[even.length];
            int[] c2help = new int[even.length];

            for (int i = 0; i < even.length; i++) {
                if (i%2 != 0) {
                    int predict;

                    if (i - image.width > 0 && i+image.width < even.length) predict = (even[i-image.width] + even[i+image.width])/2;
                    else if(i-image.width < 0 && i+image.width < even.length) predict = even[i+image.width];
                    else predict = even[i-image.width];

                    c2help[i] = odd[i] - predict;
                }
                if (i%2 == 0) {
                    int u;

                    if(i-image.width > 0 && i+image.width < even.length) u = (c2help[i-image.width] + c2help[i+image.width] + 2)/4;
                    else if(i-image.width < 0 && i+image.width < even.length) u = (2 * c2help[i+ image.width] + 2)/4;
                    else u = (2 * c2help[i - image.width] + 2)/4;

                    c1help[i] = even[i] + u;
                }
            }

            for(int i = 0; i<even.length; i++){
                if(c2help[i]!=0){
                    c2[i/2]=c2help[i];
                }
                if(c1help[i]!=0) c1[i/2]=c1help[i];
            }
        }

        return new Object[]{c1, c2};
    }

    private static void calc(int[] even, int[] odd, int[] c1, int[] c2) {

        int[] c1help = new int[even.length];
        int[] c2help = new int[even.length];

        for (int i = 0; i < even.length; i++) {
            if (i%2 != 0) {
                int predict;

                if (i + 1 < even.length) predict = (even[i-1] + even[i+1])/2;
                else predict = even[i-1];

                c2help[i] = odd[i] - predict;
            }
            if (i%2 == 0) {
                int u;

                if(i-1 > 0) u = (c2help[i-1] + c2help[i+1] + 2)/4;
                else u = (2 * c2help[1] + 2)/4;

                c1help[i] = even[i] + u;
            }
        }

        for(int i = 0; i<even.length; i++){
            if(c2help[i]!=0){
                c2[i/2]=c2help[i];
            }
            if(c1help[i]!=0) c1[i/2]=c1help[i];
        }
    }

    public static int[] LiftingSynthese(int[]c0, int[]c1){

        int[]even = new int[c1.length];
        int[]odd = new int[c1.length];

        //update backwards
        for(int i = 0; i < c0.length; i++){
            if(i >= 1 && i+1 < c0.length){
                int u = (int) Math.floor((double) (c1[i - 1] + c1[i + 1] + 2) /4);
                even[i] = c0[i] - u;
            }
            else if(i < 1){
                int u = (int) Math.floor((double) (2*c1[i + 1] + 2)/4);
                even[i] = c0[i] - u;
            }
            else{
                int u = (int) Math.floor((double) (c1[i - 1] * 2  + 2) /4);
                even[i] = c0[i] - u;
            }
        }

        //predict backwards
        for(int i = 0; i < c0.length; i++){
            if(i >= 1 && i+1 < c0.length) {
                int p = (int) Math.floor((double) (even[i - 1] + even[i + 1]) / 2);
                odd[i] = c1[i] + p;
            }
            else if(i<1) odd[i] = c1[i] + even[i + 1];
            else odd[i] = c1[i] + even[i - 1];
        }

        int[] argb = new int [c0.length*2];

        for(int i = 0; i<argb.length; i++){
            if(i % 2==0){
                argb[i] = even[i/2];
            }
            else argb[i] = odd[i/2];
        }

        for(int i = 0; i<argb.length; i++){
            argb[i] = (0xFF<<24) | (argb[i]<<16) | (argb[i] << 8) | argb[i];
        }

        return argb;
    }

}
