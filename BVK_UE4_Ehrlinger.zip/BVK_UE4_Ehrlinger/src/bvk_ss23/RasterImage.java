package bvk_ss23;

import javafx.scene.image.*;

import java.io.File;
import java.util.Arrays;

public class RasterImage {
	
	private static final int gray  = 0xffa0a0a0;

	public int[] argb;	// pixels represented as ARGB values in scanline order
	public int width;	// image width in pixels
	public int height;	// image height in pixels
	public RasterImage(int width, int height) {
		// creates an empty RasterImage of given size
		this.width = width;
		this.height = height;
		argb = new int[width * height];
		Arrays.fill(argb, gray);
	}
	
	public RasterImage(File file) {
		// creates an RasterImage by reading the given file
		Image image = null;
		if(file != null && file.exists()) {
			image = new Image(file.toURI().toString());
		}
		if(image != null && image.getPixelReader() != null) {
			width = (int)image.getWidth();
			height = (int)image.getHeight();
			argb = new int[width * height];
			image.getPixelReader().getPixels(0, 0, width, height, PixelFormat.getIntArgbInstance(), argb, 0, width);
		} else {
			// file reading failed: create an empty RasterImage
			this.width = 256;
			this.height = 256;
			argb = new int[width * height];
			Arrays.fill(argb, gray);
		}
	}

	public void convertToGray(RasterImage image) {
		for(int i = 0; i < width * height; i++) {
			int lum = image.getlum(i);
			argb[i] = (0xFF<<24) | (lum<<16) | (lum << 8) | lum;;
		}
	}
	public int getlum(int pos) {
		if( pos < 0 || pos >= width * height) return 128;
		int color = argb[pos];
		int r = (color >> 16) & 0xff;
		int g = (color >> 8) & 0xff;
		int b = (color) & 0xff;
		return (r + g + b) / 3;
	}
	public RasterImage(ImageView imageView) {
		// creates a RasterImage from that what is shown in the given ImageView
		Image image = imageView.getImage();
		width = (int)image.getWidth();
		height = (int)image.getHeight();
		argb = new int[width * height];
		image.getPixelReader().getPixels(0, 0, width, height, PixelFormat.getIntArgbInstance(), argb, 0, width);
	}

	public void setToView(ImageView imageView) {
		// sets the current argb pixels to be shown in the given ImageView
		if(argb != null) {
			WritableImage wr = new WritableImage(width, height);
			PixelWriter pw = wr.getPixelWriter();
			pw.setPixels(0, 0, width, height, PixelFormat.getIntArgbInstance(), argb, 0, width);
			imageView.setImage(wr);
		}
	}
		
	// image operations
	
	public double getMSEfromComparisonTo(RasterImage image) {
		// TODO: compare images "this" and "image" and return the Mean Square Error
		int imageWith = image.width; int imageHeight = image.height;
		double MSE =0.f;
		for(int x = 0; x < imageWith; x++) {
			for(int y = 0; y < imageHeight; y++) {
				int pos = x + y * imageWith;
				MSE += Math.pow(this.getlum(pos) - image.getlum(pos), 2);
			}
		}
		return MSE / (width * height);
	}
}
