package bvk_ss23;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.stage.FileChooser;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class RLEAppController {
	private static final String initialFileName = "test2.jpg";
	private static File fileOpenPath = new File(".");
	private RasterImage sourceImage;
	private String sourceFileName;
	private RasterImage preProcImage;
	private RasterImage rleImage;
	private int t;

    @FXML
    private ImageView sourceImageView;
    @FXML
    private ScrollPane sourceScrollPane;
    @FXML
    private Label sourceInfoLabel;
    @FXML
    private ImageView rleImageView;
    @FXML
    private ScrollPane rleScrollPane;
    @FXML
    private ImageView preProcImageView;
    @FXML
    private ScrollPane preProcScrollPane;
    @FXML
    private Label messageLabel;
    @FXML
    private Slider zoomSlider;
    @FXML
    private Label zoomLabel;
    @FXML
    private Slider tSlider;
    @FXML
    private Label tLabel;

    @FXML

    void openImage() throws IOException {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setInitialDirectory(fileOpenPath);
		fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Images (*.jpg, *.png, *.gif)", "*.jpeg", "*.jpg", "*.png", "*.gif"));
		File selectedFile = fileChooser.showOpenDialog(null);
		if(selectedFile != null) {
			zoomSlider.setValue(1);
			zoomChanged();
			fileOpenPath = selectedFile.getParentFile();
			loadAndDisplayImage(selectedFile);
			messageLabel.getScene().getWindow().sizeToScene();;
		}
    }

	@FXML
	public void initialize() throws IOException {
		loadAndDisplayImage(new File(initialFileName));
	}

	@FXML
    void zoomChanged() {
		double zoomFactor = zoomSlider.getValue();
		zoomLabel.setText(String.format("%.1f", zoomFactor));
		zoom(sourceImageView, sourceScrollPane, zoomFactor);
		zoom(rleImageView, rleScrollPane, zoomFactor);
		zoom(preProcImageView, preProcScrollPane, zoomFactor);
    }

	@FXML
	void tChanged() {
		t = (int) tSlider.getValue();
	}

	private void loadAndDisplayImage(File file) throws IOException {
		sourceFileName = file.getName();
		messageLabel.setText("Opened image " + sourceFileName);
		sourceImage = new RasterImage(file);
		sourceImage.convertToGray(sourceImage);
		sourceImage.setToView(sourceImageView);
		preProcImage = WaveletFilterbank.show(sourceImage);
		preProcImage.setToView(preProcImageView);
		sourceInfoLabel.setText("");
		rleImage = WaveletFilterbank.transformation(sourceImage);
		rleImage.setToView(rleImageView);
		compareImages();
	}

	private void compareImages() {
		/*if(sourceImage.argb.length != rleImage.argb.length || rleImageFileSize == 0) {
			rleInfoLabel.setText("");
			return;
		}
		double mse = rleImage.getMSEfromComparisonTo(sourceImage);
		rleInfoLabel.setText(String.format("MSE = %.1f", mse));*/
	}

	private void zoom(ImageView imageView, ScrollPane scrollPane, double zoomFactor) {
		if(zoomFactor == 1) {
			scrollPane.setPrefWidth(Region.USE_COMPUTED_SIZE);
			scrollPane.setPrefHeight(Region.USE_COMPUTED_SIZE);
			imageView.setFitWidth(0);
			imageView.setFitHeight(0);
		} else {
			double paneWidth = scrollPane.getWidth();
			double paneHeight = scrollPane.getHeight();
			double imgWidth = imageView.getImage().getWidth();
			double imgHeight = imageView.getImage().getHeight();
			double lastZoomFactor = imageView.getFitWidth() <= 0 ? 1 : imageView.getFitWidth() / imgWidth;
			if(scrollPane.getPrefWidth() == Region.USE_COMPUTED_SIZE)
				scrollPane.setPrefWidth(paneWidth);
			if(scrollPane.getPrefHeight() == Region.USE_COMPUTED_SIZE)
				scrollPane.setPrefHeight(paneHeight);
			double scrollX = scrollPane.getHvalue();
			double scrollY = scrollPane.getVvalue();
			double scrollXPix = ((imgWidth * lastZoomFactor - paneWidth) * scrollX + paneWidth/2) / lastZoomFactor;
			double scrollYPix = ((imgHeight * lastZoomFactor - paneHeight) * scrollY + paneHeight/2) / lastZoomFactor;
			imageView.setFitWidth(imgWidth * zoomFactor);
			imageView.setFitHeight(imgHeight * zoomFactor);
			if(imgWidth * zoomFactor > paneWidth)
				scrollX = (scrollXPix * zoomFactor - paneWidth/2) / (imgWidth * zoomFactor - paneWidth);
			if(imgHeight * zoomFactor > paneHeight)
				scrollY = (scrollYPix * zoomFactor - paneHeight/2) / (imgHeight * zoomFactor - paneHeight);
			if(scrollX < 0) scrollX = 0;
			if(scrollX > 1) scrollX = 1;
			if(scrollY < 0) scrollY = 0;
			if(scrollY > 1) scrollY = 1;
			scrollPane.setHvalue(scrollX);
			scrollPane.setVvalue(scrollY);
		}
	}
}
