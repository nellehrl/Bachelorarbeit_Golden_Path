package bvk_ss23;

import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class BitWriter {
	private DataOutputStream out;
	private ArrayList<Integer> buffer;
	public BitWriter(DataOutputStream out) {
		super();
		this.out = out;
		this.buffer = new ArrayList<Integer>();
	}

	public void writeBit(int bit) throws IOException {
		buffer.add(bit);
		if(buffer.size() == 8)writeBuffer();
	}
	public void writeDivisor(int bitNumber) throws IOException {
		for(int i = 0; i < bitNumber; i++) {
			buffer.add(1);
			if(buffer.size() == 8)writeBuffer();
		}
		buffer.add(0);
		if(buffer.size() == 8)writeBuffer();
	}
	public void writeRemainder(int value, int B) throws IOException {
		String bits = Integer.toBinaryString(value);
		while(bits.length() < B ) {
			bits = "0" + bits;
		}
		for(char bit : bits.toCharArray()) {
			if(bit == '1')buffer.add(1);
			else buffer.add(0);
			if(buffer.size() == 8)writeBuffer();
			
		}
	}
	private void writeBuffer() throws IOException {
		byte finalByte = 0;
		for(int i = 0; i < buffer.size(); i++) {
			finalByte |= buffer.get(i) << (7 - i); 
		}
		buffer.clear();
		out.write(finalByte);
	}
	public void close() throws IOException{
		for(int i = buffer.size(); i < 9; i++)buffer.add(0);
		writeBuffer();
		out.close();
	}
	
}
