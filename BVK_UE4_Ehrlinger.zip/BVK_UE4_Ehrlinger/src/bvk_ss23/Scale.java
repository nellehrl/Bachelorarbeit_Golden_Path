package bvk_ss23;

public class Scale {

    public static double[] scale(double[] a, double[] b){

        if(a[0] >= 0 && a[2] < 0.5){
           for(int i = 0; i<a.length; i++){
               if(i < 2){
                   b[i] *= 2;
               }
               a[i] *= 2;
           }
        }

        else if(a[0] >= 0.5 && a[2] <= 1){
            for(int i = 0; i<a.length; i++){
                if(i < 2){
                    b[i] = 2*(b[i]-0.5);
                }
                a[i] = 2*(a[i]-0.5);
            }
        }

        else if(a[0] >= 0.25 && a[2] < 0.75){
            for(int i = 0; i<a.length; i++){
                if(i < 2){
                    b[i] = 2*(b[i]-0.25);
                }
                a[i] = 2*(a[i]-0.25);
            }
        }

        return new double[]{a[0], a[1], a[2], b[0], b[1]};
    }
}
